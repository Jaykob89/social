import React from 'react';
import s from './Header.module.css';
const Header = () => {
    return <header className={s.header}>
        <img src = 'https://m.media-amazon.com/images/I/41i4xgZG36L._AC_SY355_.jpg'/>
    </header>
}


export default Header;